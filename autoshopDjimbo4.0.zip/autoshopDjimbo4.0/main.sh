#!/bin/bash
cd autoshopDjimbo4.0&&python3.9 main.py